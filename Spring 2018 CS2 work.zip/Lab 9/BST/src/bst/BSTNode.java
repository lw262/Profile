package bst;

public class BSTNode 
{
	protected String key; 
	protected Object element; 
	protected BSTNode left, right; 
	protected int height;
	public BSTNode (String key, Object element, BSTNode left, BSTNode right) 
	{ 
	  this.key = key; 
	  this.element = element; 
	  this.left = left; 
	  this.right = right; 
	  this.height = 0;
	} // BSTNode constructor 
	
	public int getHeight()
	{
		return height;
	}// getHeight method

	public String getKey () 
	{ 
	  return key; 
	} // getKey method 

	public Object getElement () 
	{ 
	  return element; 
	} // getElement method 

	public BSTNode getLeft () 
	{ 
	  return left; 
	} // getLeft method 

	public BSTNode getRight () 
	{ 
	  return right; 
	} // getRight method 
	
	public void setHeight (int num)
	{
		this.height = num;
	}// setHeight method

	public void setElement (Object element) 
	{ 
	  this.element = element; 
	} // setElement method 

	public void setLeft (BSTNode node) 
	{ 
	  left = node; 
	} // setLeft method 

	public void setRight (BSTNode node) 
	{ 
	  right = node; 
	} // setRight method
}
