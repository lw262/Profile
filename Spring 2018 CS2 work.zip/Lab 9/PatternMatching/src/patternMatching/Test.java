//Lauren Wineinger
//Lab 11

package patternMatching;

import javax.swing.JOptionPane;
import java.util.*;

public class Test {
	
    public static void main (String [] args)
    {
    	Scanner s = new Scanner (System.in);
    	
    	System.out.println("What file are you searching: Text.txt?");
    	String file = s.next();
    	
    	System.out.println("What would you like to search for?: ");
    	String input = s.next();
    	
        Processor p = new Processor (file);
        p.load();
        int location = p.boyerMoore(input);
        if (location == -1)
            System.out.println("Text not found.");
        else
        {
            System.out.println("Text '"+input+"' found at location: "+location);
            System.out.println("The comparisons were: "+ p.counter);
        }
    }// END main
    
}// END Test
