package p2p;

import java.util.*;
import java.io.*;

public class ListPractice 
{
	
	public static void printQuestion(ArrayList<Question> list)
	{
		
		for (int i = 0; i < list.size(); i++)
			System.out.println(list.get(i).getQuestion());
	}
	
	public static void printAnswer(ArrayList<Question> list)
	{
		
		for (int i = 0; i < list.size(); i++)
			System.out.println(list.get(i).getAnswer());
	}
	
	public static void loadQuestionArray(ArrayList list, String insertFile) throws FileNotFoundException
	{
		Scanner scan1 = new Scanner(new File (insertFile));
		while (scan1.hasNextLine())
		{
			String q = (scan1.nextLine());
			String a = (scan1.nextLine());
			list.add(new Question(q, a));
		}
	}//loadQuestionArray
	
	public void question(ArrayList<Question> list)
	{
		while (list != null)
		{
			
		}
	}
	
	public static void main (String [] args) throws FileNotFoundException
	{
		ArrayList<Question> list = new ArrayList<Question>();
		loadQuestionArray(list, "questionList1.txt");
		printQuestion(list);
		printAnswer(list);
	}
}
